package org.simplilearn;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.simplilearn.entities.Library;
import org.simplilearn.services.LibraryInsertService;
import org.simplilearn.services.LibraryReadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Sort.Direction;

@SpringBootApplication
public class SpringDataJpaDemo1Application implements CommandLineRunner{
	@Autowired
	private LibraryInsertService libraryInsertService;
	@Autowired
	private LibraryReadService libraryReadService;
	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaDemo1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//insertServiceImplMethod();
		//getAllLibraries();
		//getLibrariesPaged();
		//getLibrariesCustomPaged();
		List<Library> libraries=libraryReadService.getLibrariesSortedById(Direction.DESC);
		for(Library library:libraries)
			System.out.println(library.getId()+"\t"+library.getName()+"\t"+library.getCommaSeperatedBookNames());
	}

	private void getLibrariesCustomPaged() {
		List<Library> libraries=libraryReadService.getLibrariesCustomPaged(1, 2).get().collect(Collectors.toList());
		for(Library library:libraries)
			System.out.println(library.getId()+"\t"+library.getName()+"\t"+library.getCommaSeperatedBookNames());
	}

	private void getLibrariesPaged() {
		List<Library> libraries=libraryReadService.getLibrariesPaged().get().collect(Collectors.toList());
		for(Library library:libraries)
			System.out.println(library.getId()+"\t"+library.getName()+"\t"+library.getCommaSeperatedBookNames());
	}

	private void getAllLibraries() {
		List<Library> libraries=libraryReadService.getAllLibraries();
		for(Library library:libraries)
			System.out.println(library.getId()+"\t"+library.getName()+"\t"+library.getCommaSeperatedBookNames());
	}

	private void insertServiceImplMethod() {
		Library library1=new Library();
		library1.setName("A Library");
		library1.setCommaSeperatedBookNames("abc,def");
		Library library2=new Library();
		library2.setName("B Library");
		library2.setCommaSeperatedBookNames("xyz,def");
		Library library3=new Library();
		library3.setName("C Library");
		library3.setCommaSeperatedBookNames("tuv,fgh");
		Library library4=new Library();
		library4.setName("D Library");
		library4.setCommaSeperatedBookNames("dgh,kgh");
		List<Library> libraries=new ArrayList<>();
		libraries.add(library1);
		libraries.add(library2);
		libraries.add(library3);
		libraries.add(library4);
		libraryInsertService.addMultipleLibraries(libraries);
	}

}
