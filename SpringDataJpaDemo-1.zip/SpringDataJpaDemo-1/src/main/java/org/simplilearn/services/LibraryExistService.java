package org.simplilearn.services;

public interface LibraryExistService {
	boolean checkLibraryExistsById(int id);
	boolean checkLibraryExistsByExample(String commaSeperatedNames);
}
