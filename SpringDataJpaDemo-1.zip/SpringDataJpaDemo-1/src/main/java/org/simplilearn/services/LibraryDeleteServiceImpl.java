package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Library;
import org.simplilearn.repositories.LibraryRepository;
import org.springframework.stereotype.Service;

@Service
public class LibraryDeleteServiceImpl implements LibraryDeleteService{
	private LibraryRepository libraryRepository;
	
	public LibraryDeleteServiceImpl(LibraryRepository libraryRepository) {
		super();
		this.libraryRepository = libraryRepository;
	}

	@Override
	public String deleteOneLibrary(Library library) {
		libraryRepository.delete(library);
		return "Library Deleted";
	}

	@Override
	public String pruneTable() {
		libraryRepository.deleteAll();
		return "prune completed";
	}

	@Override
	public String deleteAllThese(List<Library> libraries) {
		libraryRepository.deleteAll(libraries);
		return "Delete All completed";
	}

	@Override
	public String deleteAllInBatch() {
		libraryRepository.deleteAllInBatch();
		return "Delete All in Batch Completed";
	}

	@Override
	public String deleteById(int lid) {
		libraryRepository.deleteById(lid);
		return "Library with id "+lid+" is deleted";
	}

	@Override
	public String deleteAllTheseInBatch(List<Library> libraries) {
		libraryRepository.deleteAllInBatch(libraries);
		return "Deleted";
	}

}
