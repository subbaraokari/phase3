package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Library;
import org.simplilearn.repositories.LibraryRepository;
import org.springframework.stereotype.Service;

@Service
public class LibraryInsertServiceImpl implements LibraryInsertService{
	private LibraryRepository libraryRepository;
	
	public LibraryInsertServiceImpl(LibraryRepository libraryRepository) {
		this.libraryRepository=libraryRepository;
	}
	@Override
	public String addSingleLibrary(Library library) {
		libraryRepository.save(library);
		libraryRepository.flush();
		return "Library Inserted";
	}

	@Override
	public String addMultipleLibraries(List<Library> libraries) {
		libraryRepository.saveAll(libraries);
		libraryRepository.flush();
		return "libraries inserted";
	}

	@Override
	public String addLibraryWithSaveAndFlush(Library library) {
		libraryRepository.saveAndFlush(library);
		return "library inserted";
	}

}
