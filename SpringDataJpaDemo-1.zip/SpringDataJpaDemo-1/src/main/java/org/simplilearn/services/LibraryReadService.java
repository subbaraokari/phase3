package org.simplilearn.services;

import java.util.List;
import java.util.Optional;

import org.simplilearn.entities.Library;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort.Direction;

public interface LibraryReadService {
	List<Library> getAllLibraries();
	List<Library> getAllLibrariesWithZeroBooks();
	Page<Library> getLibrariesPaged();
	Page<Library> getLibrariesCustomPaged(int pageNumber,int numberOfRecordsPerPage);
	List<Library> getLibrariesWithLatestAddedOrder();
	List<Library> getLibrariesSortedById(Direction direction);
	List<Library> getLibrariesSortedByName(Direction direction);
	Page<Library> getLibrariesCustomPagedAndSortedWithDefaultOrderByNameAndWithTheseBooks(String commaSeperatedNames,int pageNo,int numberOfRecordsOnPage);
	List<Library> getLibrariesSortedByNameAndWithTheseBooks(String commaSeperatedBookNames);
	List<Library> getLibrariesByids(List<Integer> ids);
	Optional<Library> getLibraryById(int id);
	Page<Library> getLibrariesPagedAndSortedByName();
	
}
