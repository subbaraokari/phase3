package org.simplilearn.services;

import org.simplilearn.entities.Library;
import org.simplilearn.repositories.LibraryRepository;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

@Service
public class LibraryExistsServiceImpl implements LibraryExistService{
	private LibraryRepository libraryRepository;
	
	public LibraryExistsServiceImpl(LibraryRepository libraryRepository) {
		super();
		this.libraryRepository = libraryRepository;
	}

	@Override
	public boolean checkLibraryExistsById(int id) {
		return libraryRepository.existsById(id);
	}

	@Override
	public boolean checkLibraryExistsByExample(String commaSeperatedNames) {
		Library library=new Library();
		library.setCommaSeperatedBookNames(commaSeperatedNames);
		ExampleMatcher exampleMatcher=ExampleMatcher.matching()
				.withMatcher("commaSeperatedNames", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("id","name");
		Example<Library> example=Example.of(library, exampleMatcher);
		return libraryRepository.exists(example);
	}

}
