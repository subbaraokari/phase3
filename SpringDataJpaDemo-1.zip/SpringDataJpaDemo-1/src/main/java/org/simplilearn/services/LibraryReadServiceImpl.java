package org.simplilearn.services;

import java.util.List;
import java.util.Optional;

import org.simplilearn.entities.Library;
import org.simplilearn.repositories.LibraryRepository;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

@Service
public class LibraryReadServiceImpl implements LibraryReadService{
	private LibraryRepository libraryRepository;
	
	public LibraryReadServiceImpl(LibraryRepository libraryRepository) {
		super();
		this.libraryRepository = libraryRepository;
	}

	@Override
	public List<Library> getAllLibraries() {
		return libraryRepository.findAll();
	}

	@Override
	public List<Library> getAllLibrariesWithZeroBooks() {
		Library library=new Library();
		library.setCommaSeperatedBookNames("");
		ExampleMatcher exampleMatcher=ExampleMatcher.matching()
				.withMatcher("commaSeperatedBookNames", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("id","name");
		Example<Library> example=Example.of(library, exampleMatcher);
		return libraryRepository.findAll(example);
	}

	@Override
	public Page<Library> getLibrariesPaged() {
		Pageable pageable=PageRequest.of(0, 3);
		return libraryRepository.findAll(pageable);
	}

	@Override
	public Page<Library> getLibrariesCustomPaged(int pageNumber, int numberOfRecordsPerPage) {
		Pageable pageable=PageRequest.of(pageNumber, numberOfRecordsPerPage);
		return libraryRepository.findAll(pageable);
	}

	@Override
	public List<Library> getLibrariesWithLatestAddedOrder() {
		return libraryRepository.findAll(Sort.by(Direction.DESC, "id"));
	}

	@Override
	public List<Library> getLibrariesSortedById(Direction direction) {
		return libraryRepository.findAll(Sort.by(direction, "id"));
	}

	@Override
	public List<Library> getLibrariesSortedByName(Direction direction) {
		
		return libraryRepository.findAll(Sort.by(direction, "name"));
	}

	@Override
	public Page<Library> getLibrariesCustomPagedAndSortedWithDefaultOrderByNameAndWithTheseBooks(
			String commaSeperatedNames, int pageNo, int numberOfRecordsOnPage) {
		Library library=new Library();
		library.setCommaSeperatedBookNames(commaSeperatedNames);
		ExampleMatcher exampleMatcher=ExampleMatcher.matching()
				.withMatcher("commaSeperatedNames", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("id","name");
		Example<Library> example=Example.of(library, exampleMatcher);
		Pageable pageable=PageRequest.of(pageNo, numberOfRecordsOnPage, Sort.by("name"));
		return libraryRepository.findAll(example, pageable);
	}

	@Override
	public List<Library> getLibrariesSortedByNameAndWithTheseBooks(String commaSeperatedBookNames) {
		Library library=new Library();
		library.setCommaSeperatedBookNames(commaSeperatedBookNames);
		ExampleMatcher exampleMatcher=ExampleMatcher.matching()
				.withMatcher("commaSeperatedBookNames", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("id","name");
		Example<Library> example=Example.of(library, exampleMatcher);
		return libraryRepository.findAll(example, Sort.by("name"));
	}

	@Override
	public List<Library> getLibrariesByids(List<Integer> ids) {
		return libraryRepository.findAllById(ids);
	}

	@Override
	public Optional<Library> getLibraryById(int id) {
		return libraryRepository.findById(id);
	}

	@Override
	public Page<Library> getLibrariesPagedAndSortedByName() {
		Pageable pageable=PageRequest.of(0, 2, Sort.by("name"));
		return libraryRepository.findAll(pageable);
	}

}
