package org.simplilearn.services;

public interface LibraryCountService {
	long countLibraries();
	long countLibrariesWithZeroBooks();
}
