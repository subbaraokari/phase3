package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Library;

public interface LibraryDeleteService {
	String deleteOneLibrary(Library library);
	String pruneTable();
	String deleteAllThese(List<Library> libraries);
	String deleteAllInBatch();
	String deleteById(int lid);
	String deleteAllTheseInBatch(List<Library> libraries);
}
