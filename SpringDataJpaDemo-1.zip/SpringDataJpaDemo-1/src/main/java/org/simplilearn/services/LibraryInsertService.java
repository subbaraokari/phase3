package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Library;

public interface LibraryInsertService {
	String addSingleLibrary(Library library);
	String addMultipleLibraries(List<Library> libraries);
	String addLibraryWithSaveAndFlush(Library library);
}
