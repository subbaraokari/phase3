package org.simplilearn.services;

import org.simplilearn.entites.Cart;
import org.simplilearn.entites.User;
import org.simplilearn.models.CartModel;
import org.simplilearn.repositories.CartRepository;
import org.simplilearn.repositories.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class CartService {
	private CartRepository cartRepository;
	private UserRepository userRepository;
	
	public CartService(CartRepository cartRepository,UserRepository userRepository) {
		super();
		this.cartRepository = cartRepository;
	}

	public void addToCart(User user,CartModel cartModel) {
		User user1=userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		Cart cart=cartRepository.findByItem(cartModel.getItem());
		if(cart!=null)
		{
			cart.setQty(cart.getQty()+1);
			cart.setPrice(cart.getQty()*cartModel.getPrice());
			user.setCart(cart);
			userRepository.save(user);
			cartRepository.save(cart);
		}
		
	}
}
