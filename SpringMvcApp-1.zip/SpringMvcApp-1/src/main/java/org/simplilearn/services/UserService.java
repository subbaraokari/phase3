package org.simplilearn.services;

import org.simplilearn.entites.User;
import org.simplilearn.models.LoginDto;
import org.simplilearn.models.UserDto;

public interface UserService {
	User register(UserDto userDto);
	User login(LoginDto loginDto);
}
