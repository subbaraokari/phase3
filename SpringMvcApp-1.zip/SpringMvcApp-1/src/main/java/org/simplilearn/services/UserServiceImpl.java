package org.simplilearn.services;

import org.simplilearn.entites.User;
import org.simplilearn.models.LoginDto;
import org.simplilearn.models.UserDto;
import org.simplilearn.repositories.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{
	private UserRepository userRepository;
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}


	@Override
	public User register(UserDto userDto) {
		User user=new User();
		user.setUsername(userDto.getUsername());
		user.setPassword(userDto.getPassword());
		user.setEmail(userDto.getEmail());
		user.setRole(userDto.getRole());
		return userRepository.save(user);
	}


	@Override
	public User login(LoginDto loginDto) {
		String username=loginDto.getUsername();
		String password=loginDto.getPassword();
		User user=userRepository.findByUsernameAndPassword(username, password);
		return user;
	}

}
