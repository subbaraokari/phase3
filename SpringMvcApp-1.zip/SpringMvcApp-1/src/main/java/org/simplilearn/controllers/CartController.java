package org.simplilearn.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CartController {
	@RequestMapping("/addToCart/{pid}")
	public String addToCart(int pid) {
		
	}
}
