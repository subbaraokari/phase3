package org.simplilearn.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.simplilearn.entites.Product;
import org.simplilearn.entites.User;
import org.simplilearn.models.LoginDto;
import org.simplilearn.models.UserDto;
import org.simplilearn.services.ProductService;
import org.simplilearn.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	private UserService userService;
	private ProductService productService;
	
	@Autowired
	public UserController(UserService userService,ProductService productService) {
		super();
		this.userService = userService;
		this.productService=productService;
	}
	
	@RequestMapping("/")
	public String showHome()
	{
		return "home";
	}
	@RequestMapping("/showLogin")
	public String showLogin() {
		return "login";
	}
	@RequestMapping("/showSignUp")
	public String showSignUp() {
		return "signup";
	}
	@RequestMapping(value = "/signUp",method = RequestMethod.POST)
	public String register(@RequestParam("username") String username,@RequestParam("password") String password,@RequestParam("email") String email,Model model) {
		//String username=request.getParameter("username");
		//String password=request.getParameter("password");
		//String email=request.getParameter("email");
		UserDto userDto=new UserDto();
		userDto.setUsername(username);
		userDto.setPassword(password);
		userDto.setEmail(email);
		userDto.setRole("Customer");
		User user=userService.register(userDto);
		if(user!=null)
			model.addAttribute("msg", "User Registered Successfully");
		else
			model.addAttribute("msg", "Not Registered");
		return "signup";
			
	}
	@RequestMapping(value = "/login",method = RequestMethod.POST)
	public String login(@RequestParam("username") String username,Model model,
			@RequestParam("password") String password,HttpSession session) {
		String viewName=null;
		LoginDto loginDto=new LoginDto();
		loginDto.setUsername(username);
		loginDto.setPassword(password);
		User user=userService.login(loginDto);
		if(user!=null) {
			session.setAttribute("user", user);
			if(user.getRole().equals("Admin"))
				viewName="adminDashboard";
			else
			{
				List<Product> products=productService.getAll();
				model.addAttribute("products",products);
				viewName="customerDashboard";
			}
				
		}
		else
		{
			model.addAttribute("msg", "Username/Password is wrong");
			viewName="login";
		}
		return viewName;
	}
	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.setAttribute("user", null);
		session.invalidate();
		return "redirect:/";
		
	}
}
