package org.simplilearn.repositories;

import org.simplilearn.entites.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Integer>{
	Cart findByItem(String item);
}
