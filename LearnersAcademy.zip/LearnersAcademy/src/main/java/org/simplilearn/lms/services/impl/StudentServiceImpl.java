package org.simplilearn.lms.services.impl;

import org.simplilearn.lms.dao.StudentDao;
import org.simplilearn.lms.dao.UserDao;
import org.simplilearn.lms.daoimpl.StudentDaoImpl;
import org.simplilearn.lms.daoimpl.UserDaoImpl;
import org.simplilearn.lms.entities.Student;
import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.StudentModel;
import org.simplilearn.lms.services.StudentService;
import org.simplilearn.lms.services.UserService;

public class StudentServiceImpl implements StudentService{
	private StudentDao dao=new StudentDaoImpl();
	private UserDao userDao=new UserDaoImpl();
	@Override
	public void addStudent(User user, StudentModel studentModel) {
		User user1=userDao.get(user.getUsername(), user.getPassword());
		Student student=new Student();
		student.setSname(studentModel.getName());
		student.setAddress(studentModel.getAddress());
		user1.addStudent(student);
		student.setUser(user1);
		dao.add(student);
	}

}
