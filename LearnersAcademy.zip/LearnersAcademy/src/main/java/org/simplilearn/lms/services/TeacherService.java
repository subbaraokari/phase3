package org.simplilearn.lms.services;

import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.TeacherModel;

public interface TeacherService {
	void addTeacher(User user,TeacherModel teacherModel);
}
