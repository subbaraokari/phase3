package org.simplilearn.lms.services;

import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.StudentModel;

public interface StudentService {
	void addStudent(User user,StudentModel studentModel);
}
