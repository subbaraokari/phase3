package org.simplilearn.lms.dao;

import java.util.List;

import org.simplilearn.lms.entities.Student;

public interface StudentDao {
	void add(Student student);
	void delete(int sid);
	List<Student> getAll();
}
