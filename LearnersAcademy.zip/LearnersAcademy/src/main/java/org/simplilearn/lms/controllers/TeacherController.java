package org.simplilearn.lms.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.TeacherModel;
import org.simplilearn.lms.services.TeacherService;
import org.simplilearn.lms.services.impl.TeacherServiceImpl;

import com.mysql.cj.Session;


@WebServlet("/addTeacher")
public class TeacherController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TeacherService service=new TeacherServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String qual=request.getParameter("qual");
		TeacherModel teacherModel=new TeacherModel();
		teacherModel.setName(name);
		teacherModel.setQualification(qual);
		HttpSession session=request.getSession();
		User user=(User) session.getAttribute("user");
		service.addTeacher(user, teacherModel);
		RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
		rd.forward(request, response);
		
	}

}
