package org.simplilearn.lms.dao;

import java.util.List;

import org.simplilearn.lms.entities.Subject;

public interface SubjectDao {
	void add(Subject subject);
	void delete(int sid);
	List<Subject> getAll();
}
