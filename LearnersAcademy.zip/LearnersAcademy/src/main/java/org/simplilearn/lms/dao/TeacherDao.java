package org.simplilearn.lms.dao;

import java.util.List;

import org.simplilearn.lms.entities.Teacher;

public interface TeacherDao {
	void add(Teacher teacher);
	void delete(int tid);
	List<Teacher> getAll();
	
}
