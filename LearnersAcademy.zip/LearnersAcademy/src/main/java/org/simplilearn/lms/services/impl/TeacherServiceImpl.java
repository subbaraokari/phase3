package org.simplilearn.lms.services.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.lms.config.HibConfig;
import org.simplilearn.lms.dao.TeacherDao;
import org.simplilearn.lms.dao.UserDao;
import org.simplilearn.lms.daoimpl.TeacherDaoImpl;
import org.simplilearn.lms.daoimpl.UserDaoImpl;
import org.simplilearn.lms.entities.Teacher;
import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.TeacherModel;
import org.simplilearn.lms.services.TeacherService;

public class TeacherServiceImpl implements TeacherService{
	private UserDao userDao=new UserDaoImpl();
	private TeacherDao teacherDao=new TeacherDaoImpl();
	@Override
	public void addTeacher(User user, TeacherModel teacherModel) {
			Teacher teacher=new Teacher();
			teacher.setName(teacherModel.getName());
			teacher.setQual(teacherModel.getQualification());
			User user1=userDao.get(user.getUsername(), user.getPassword());
			user1.addTeacher(teacher);
			teacher.setUser(user1);
			teacherDao.add(teacher);
	}
	
}
