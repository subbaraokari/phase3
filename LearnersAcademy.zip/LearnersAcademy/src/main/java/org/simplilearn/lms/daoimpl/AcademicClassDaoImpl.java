package org.simplilearn.lms.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.lms.config.HibConfig;
import org.simplilearn.lms.dao.AcademicClassDao;
import org.simplilearn.lms.entities.AcdemicClass;
import org.simplilearn.lms.entities.Student;

public class AcademicClassDaoImpl implements AcademicClassDao{

	@Override
	public void add(AcdemicClass acdemicClass) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(acdemicClass);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
	}

	@Override
	public void delete(int id) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			AcdemicClass class1=session.get(AcdemicClass.class, id);
			session.delete(class1);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
	}

	@Override
	public List<AcdemicClass> getAll() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Query<AcdemicClass> query=session.createQuery("select a from org.simplilearn.lms.entities.AcdemicClass a");
		return query.list();
	}

}
