package org.simplilearn.lms.services;

import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.LoginModel;
import org.simplilearn.lms.models.UserModel;

public interface UserService {
	void register(UserModel userModel);
	User getUser(LoginModel userModel);
}
