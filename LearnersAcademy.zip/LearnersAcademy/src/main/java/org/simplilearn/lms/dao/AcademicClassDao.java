package org.simplilearn.lms.dao;

import java.util.List;

import org.simplilearn.lms.entities.AcdemicClass;

public interface AcademicClassDao {
	void add(AcdemicClass acdemicClass);
	void delete(int id);
	List<AcdemicClass> getAll();
}
