package org.simplilearn.lms.services.impl;

import org.simplilearn.lms.dao.UserDao;
import org.simplilearn.lms.daoimpl.UserDaoImpl;
import org.simplilearn.lms.entities.User;
import org.simplilearn.lms.models.LoginModel;
import org.simplilearn.lms.models.UserModel;
import org.simplilearn.lms.services.UserService;

public class UserServiceImpl implements UserService{
	private UserDao dao=new UserDaoImpl();
	@Override
	public void register(UserModel userModel) {
		User user=new User();
		user.setUsername(userModel.getUsername());
		user.setPassword(userModel.getPassword());
		user.setEmail(userModel.getEmail());
		dao.insert(user);
	}
	@Override
	public User getUser(LoginModel loginModel) {
		return dao.get(loginModel.getUsername(), loginModel.getPassword());
	}

}
