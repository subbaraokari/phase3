package org.simplilearn.exceptions;

public class CustomerNotFoundException extends RuntimeException{
	public CustomerNotFoundException(String desc) {
		super(desc);
	}
}
