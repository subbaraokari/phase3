package org.simplilearn.controllers;

import java.time.LocalDateTime;
import java.util.List;

import org.simplilearn.entities.Customer;
import org.simplilearn.entities.ErrorResponse;
import org.simplilearn.exceptions.CustomerNotFoundException;
import org.simplilearn.services.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController  //=@Controller + @ResponseBody
@RequestMapping("/api")
public class CustomerController {
	private CustomerService customerService;
	
	public CustomerController(CustomerService customerService) {
		super();
		this.customerService = customerService;
	}
	@PostMapping("/customers")
	public ResponseEntity<Customer> insertCustomer(@RequestBody Customer customer){
		Customer customer1=customerService.insertCustomer(customer);
		ResponseEntity<Customer> responseEntity=new ResponseEntity<Customer>(customer1, HttpStatus.CREATED);
		return responseEntity;
	}
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getCustomers(){
		List<Customer> customers=customerService.getCustomers();
		ResponseEntity<List<Customer>> responseEntity=new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
		return responseEntity;
	}
	@DeleteMapping("/customers/delete/{cid}")
	public ResponseEntity<?> deleteCustomer(@PathVariable("cid") int cid){
		customerService.deleteCustomer(cid);
		ResponseEntity<String> responseEntity=new ResponseEntity<String>("Deleted Successfully", HttpStatus.OK);
		return responseEntity;
	}
	@GetMapping("/customers/get/{cid}")
	public ResponseEntity<Customer> getCustomer(@PathVariable("cid") int cid){
		Customer customer=customerService.getCustomer(cid);
		ResponseEntity<Customer> responseEntity=new ResponseEntity<Customer>(customer, HttpStatus.OK);
		return responseEntity;
	}
	@PutMapping("/customers/put/{cid}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable("cid") int cid,
			@RequestBody Customer customer){
		Customer customer2=customerService.updateCustomer(cid, customer);
		ResponseEntity<Customer> responseEntity=new ResponseEntity<Customer>(customer2, HttpStatus.OK);
		return responseEntity;
	}
	
}
