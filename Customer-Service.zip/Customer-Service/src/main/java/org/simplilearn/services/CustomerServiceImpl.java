package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Customer;
import org.simplilearn.exceptions.CustomerNotFoundException;
import org.simplilearn.repositories.CustomerRepository;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService{
	private CustomerRepository customerRepository;
	
	public CustomerServiceImpl(CustomerRepository customerRepository) {
		super();
		this.customerRepository = customerRepository;
	}

	@Override
	public Customer insertCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomer(int cid) {
		customerRepository.deleteById(cid);
	}
	@Override
	public List<Customer> getCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomer(int cid) {
		return customerRepository.findById(cid).orElseThrow(()->new CustomerNotFoundException("Customer not found"));
	}

	@Override
	public Customer updateCustomer(int cid, Customer customer) {
		Customer customer2=getCustomer(cid);
		customer2.setCustomerName(customer.getCustomerName());
		customer2.setAddress(customer.getAddress());
		customer2.setDob(customer.getDob());
		customerRepository.save(customer2);
		return customer2;
	}

}
