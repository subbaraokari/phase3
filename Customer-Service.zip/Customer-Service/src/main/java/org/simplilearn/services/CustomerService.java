package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Customer;

public interface CustomerService {
	Customer insertCustomer(Customer customer);
	void deleteCustomer(int cid);
	List<Customer> getCustomers();
	Customer getCustomer(int cid);
	Customer updateCustomer(int cid,Customer customer);
	
}
