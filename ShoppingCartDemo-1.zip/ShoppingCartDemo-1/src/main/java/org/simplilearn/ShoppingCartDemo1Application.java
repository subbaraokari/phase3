package org.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCartDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartDemo1Application.class, args);
	}

}
